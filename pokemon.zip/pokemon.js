$(document).ready(function(){

    for(var i=1;i<152;i++){
        $("body").before("<img src='http://pokeapi.co/media/img/"+i+".png' alt='a picture of a pokemon'>");
    }
});